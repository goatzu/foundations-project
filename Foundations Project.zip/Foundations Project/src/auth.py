from flask import Blueprint, render_template, request, flash

auth_blueprint = Blueprint('auth', __name__)

@auth_blueprint.route('/')
def auth():
    return "<h1> selection what you want to do </h1>"

@auth_blueprint.route('/login', methods=['GET', 'POST'])
def login():
    return render_template("login.html")

@auth_blueprint.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('username')
        password = request.form.get('password')
        password_confirm = request.form.get('password_confirm')

        if len(email) < 4:
            flash('Email must be greater than 4 characters', category='error')
        elif len(username) < 4:
            flash('Username must be greater than 4 characters', category='error')
        elif password != password_confirm:
            flash('Passwords do not match.', category='error')
        elif len(password) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            flash('Account got created! ', category='success')


    return render_template("register.html")