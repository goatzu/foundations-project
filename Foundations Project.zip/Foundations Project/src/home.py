from flask import Blueprint

home_blueprint = Blueprint('home', __name__)

@home_blueprint.route('/')
def home():
    return "<h1> Test </h1>"