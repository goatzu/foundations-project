from flask import Flask
from src.auth import auth_blueprint
from src.home import home_blueprint
from flask_sqlalchemy import SQLAlchemy
from os import path

db = SQLAlchemy()
DB_NAME = "database.db"

def create_database(app):
    if not path.exists('src/' + DB_NAME):
        db.create_all(app=app)
        print('created database... ')

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'production'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}'
    db.init_app(app)

    app.register_blueprint(auth_blueprint, url_prefix='/auth')
    app.register_blueprint(home_blueprint, url_prefix='/')

    from .datamodels import User, DiaryEntry

    create_database(app)

    return app

app = create_app()
